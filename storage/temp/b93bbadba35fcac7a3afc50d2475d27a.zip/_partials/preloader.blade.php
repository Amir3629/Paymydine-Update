<div id="preloader">
    <div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
        <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
        <span class="visually-hidden">Loading...</span>
    </div>
</div>