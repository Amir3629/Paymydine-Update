<div id="local-box">    

    @partial($__SELF__.'::default')

</div>
