"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js"
import { PayPalButtons, usePayPalScriptReducer } from "@paypal/react-paypal-js"
import { Session, PaymentRequest } from "onlinepayments-sdk-client-js"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ThemedButton, ThemedInput } from "@/components/theme-ui"
import { PaymentSecurity, PaymentData, PaymentResult } from "@/lib/payment-service"
import { Lock, CreditCard, AlertCircle, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface SecurePaymentFormProps {
  paymentData: PaymentData
  onPaymentComplete: (result: PaymentResult) => void
  onPaymentError: (error: string) => void
  className?: string
  footerSlot?: React.ReactNode
  paypalFundingSource?: "paypal" | "card"
}

interface WorldlineInlineCardFormProps extends SecurePaymentFormProps {
  countryCode?: string
  currency?: string
}

const worldlineInlineInitPromiseByKey = new Map<string, Promise<{ sdk: any; paymentProduct: any }>>()
const worldlineInlineInitResultByKey = new Map<string, { sdk: any; paymentProduct: any }>()

// Stripe Card Form Component
export function StripeCardForm({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className,
  footerSlot
}: SecurePaymentFormProps) {
  const stripe = useStripe()
  const elements = useElements()
  const [isProcessing, setIsProcessing] = useState(false)
  const [cardError, setCardError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    cardholderName: "",
    email: "",
    phone: "",
  })
  const isSubmittingRef = useRef(false)
  const cardMountedRef = useRef(false)
  const [cardMounted, setCardMounted] = useState(false)
  const [cardReady, setCardReady] = useState(false)
  const [cardComplete, setCardComplete] = useState(false)

  const fieldTheme = useMemo(() => {
    if (typeof window === "undefined") {
      return {
        text: "#111827",
        muted: "#6B7280",
      }
    }

    try {
      const checkoutTheme = document
        .querySelector('[data-pmd-checkout-theme-root="1"]')
        ?.getAttribute("data-pmd-checkout-theme")

      if (checkoutTheme === "kazen_japanese" || checkoutTheme === "kazen-japanese") {
        return { text: "#242320", muted: "rgba(36, 35, 32, 0.52)" }
      }

      if (checkoutTheme === "gold-luxury") {
        return { text: "#FFF8DC", muted: "rgba(255, 248, 220, 0.58)" }
      }

      if (checkoutTheme === "modern_green" || checkoutTheme === "modern-green") {
        return { text: "#F5FFF8", muted: "#92c7ac" }
      }

      return {
        text: "var(--pmd-checkout-input-fg, #111827)",
        muted: "var(--pmd-checkout-card-muted, #6B7280)",
      }
    } catch {
      return {
        text: "var(--pmd-checkout-input-fg, #111827)",
        muted: "var(--pmd-checkout-card-muted, #6B7280)",
      }
    }
  }, [])

  const cardElementOptions = useMemo(() => ({
    style: {
      base: {
        fontSize: "16px",
        color: fieldTheme.text,
        iconColor: fieldTheme.text,
        "::placeholder": {
          color: fieldTheme.muted,
        },
      },
      invalid: {
        color: "#EF4444",
        iconColor: "#EF4444",
      },
    },
  }), [fieldTheme])

  const canSubmitCardPayment = Boolean(
    stripe &&
    elements &&
    cardMounted &&
    cardReady &&
    cardComplete &&
    !isProcessing &&
    !isSubmittingRef.current,
  )

  useEffect(() => {
    return () => {
      cardMountedRef.current = false
    }
  }, [])

  const handleCardChange = (event: any) => {
    setCardComplete(Boolean(event?.complete))
    setCardError(event.error ? event.error.message : null)
  }



  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (isSubmittingRef.current || isProcessing) {
      return
    }

    setCardError(null)

    if (!stripe || !elements) {
      const msg = "Secure card payment is still loading. Please wait a moment and try again."
      setCardError(msg)
      onPaymentError(msg)
      return
    }

    const cardElement = elements.getElement(CardElement)
    if (!cardElement || !cardReady || !cardMountedRef.current) {
      const msg = "Secure card field is not ready yet. Please wait a moment and try again."
      setCardError(msg)
      onPaymentError(msg)
      return
    }

    isSubmittingRef.current = true
    setIsProcessing(true)

    try {
      const amount = Number(paymentData?.amount || 0)
      const currency = String(paymentData?.currency || "EUR").toUpperCase()

      if (!amount || amount <= 0) {
        throw new Error("Invalid payment amount")
      }

      const response = await fetch("/api/v1/payments/stripe/create-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount,
          currency,
          restaurantId: String((paymentData as any)?.restaurantId || "1"),
          tableNumber: (paymentData as any)?.tableNumber ?? null,
          cartId: (paymentData as any)?.cartId ?? null,
          userId: (paymentData as any)?.userId ?? null,
          items: Array.isArray((paymentData as any)?.items) ? (paymentData as any)?.items : [],
          customerInfo: (paymentData as any)?.customerInfo || {},
        }),
      })

      const payload = await response.json().catch(() => ({} as any))

      if (!response.ok || !payload?.clientSecret) {
        throw new Error(payload?.error || "Failed to create Stripe payment intent")
      }

      const billingName =
        String(formData.cardholderName || "").trim() ||
        String((paymentData as any)?.customerInfo?.name || "").trim() ||
        "Customer"

      const billingEmail = String(formData.email || "").trim() || undefined
      const billingPhone = String(formData.phone || "").trim() || undefined

      const { error, paymentIntent } = await stripe.confirmCardPayment(payload.clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            name: billingName,
            email: billingEmail,
            phone: billingPhone,
          },
        },
      })

      if (error) {
        throw new Error(error.message || "Stripe payment confirmation failed")
      }

      const status = String(paymentIntent?.status || "")
      if (!paymentIntent || !["succeeded", "processing", "requires_capture"].includes(status)) {
        throw new Error(`Unexpected Stripe payment status: ${status || "unknown"}`)
      }

      onPaymentComplete({
        success: true,
        transactionId: String(paymentIntent.id),
        paymentMethod: "stripe",
      } as any)
    } catch (error: any) {
      const msg = typeof error?.message === "string" ? error.message : "Stripe payment failed"
      setCardError(msg)
      onPaymentError(msg)
    } finally {
      isSubmittingRef.current = false
      setIsProcessing(false)
    }
  }


  return (
    <form data-pmd-stripe-form="1" onSubmit={handleSubmit} className={cn("space-y-4 bg-transparent w-full", className)}>
      <div className="space-y-3">
        <div>
          <Label htmlFor="cardholderName" className="pmd-themed-label text-sm font-medium">
            Cardholder Name
          </Label>
          <ThemedInput
            id="cardholderName"
            type="text"
            placeholder="John Doe"
            value={formData.cardholderName}
            onChange={(e) => setFormData(prev => ({ ...prev, cardholderName: e.target.value }))}
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="email" className="pmd-themed-label text-sm font-medium">
            Email Address
          </Label>
          <ThemedInput
            id="email"
            type="email"
            placeholder="john@example.com"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="phone" className="pmd-themed-label text-sm font-medium">
            Phone Number (Optional)
          </Label>
          <ThemedInput
            id="phone"
            type="tel"
            placeholder="+1 (555) 123-4567"
            value={formData.phone}
            onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
            className="mt-1"
          />
        </div>

        <div>
          <Label className="pmd-themed-label text-sm font-medium">
            Card Information
          </Label>
          <div className="pmd-stripe-card-frame mt-1">
            <CardElement
              options={cardElementOptions}
              onReady={() => {
                cardMountedRef.current = true
                setCardMounted(true)
                setCardReady(true)
                setCardError(null)
              }}
              onChange={handleCardChange}
            />
          </div>
          {cardError && (
            <div className="flex items-center gap-2 mt-2 text-red-600 text-sm">
              <AlertCircle className="h-4 w-4" />
              {cardError}
            </div>
          )}
        </div>
      </div>
      {footerSlot ? <div className="pt-3 pb-2 flex items-center gap-2">{footerSlot}</div> : null}


      <ThemedButton
        type="submit"
        disabled={!canSubmitCardPayment}
        data-pmd-stripe-native-button="1"
        variant="primary"
        fullWidth
      >
        {isProcessing ? (
          <span className="flex w-full items-center justify-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-current/35 border-t-current" />
            <span>Processing...</span>
          </span>
        ) : (
          <span className="flex w-full items-center justify-center gap-2">
            <Lock className="h-4 w-4 flex-none" />
            <span>Pay</span>
          </span>
        )}
      </ThemedButton>
    </form>
  )
}

export function WorldlineInlineCardForm({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className,
  countryCode = "DE",
  currency = "EUR",
}: WorldlineInlineCardFormProps) {
  const initFailureShownRef = useRef(false)
  const onPaymentErrorRef = useRef(onPaymentError)
  const initKeyRef = useRef<string | null>(null)
  const [isLoadingSession, setIsLoadingSession] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [sdk, setSdk] = useState<any>(null)
  const [paymentProduct, setPaymentProduct] = useState<any>(null)
  const [formData, setFormData] = useState({
    cardholderName: "",
    email: "",
    phone: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  })
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const amountMinor = Math.round(Number(paymentData?.amount || 0) * 100)
  const formIsValid = useMemo(() => {
    return Boolean(
      formData.cardholderName.trim() &&
      formData.email.trim() &&
      formData.cardNumber.trim() &&
      formData.expiryDate.trim() &&
      formData.cvv.trim() &&
      Object.values(fieldErrors).every((err) => !err)
    )
  }, [fieldErrors, formData])
  const currencyCode = String(currency || "EUR").toUpperCase()

  const normalizeCardNumber = (value: any) => String(value ?? "").replace(/\D/g, "")
  const normalizeExpiry = (value: any) => {
    return String(value ?? "").replace(/\D/g, "").slice(0, 4)
  }
  const normalizeCvv = (value: any) => String(value ?? "").replace(/\D/g, "")

  const getExpiryDigits = (value: any) => String(value ?? "").replace(/\D/g, "").slice(0, 4)

  const getPaymentRequestProbe = (paymentRequest: any) => {
    const safeGet = (key: string) => {
      try {
        if (typeof paymentRequest?.getValue === "function") {
          return paymentRequest.getValue(key)
        }
      } catch {}
      try {
        return paymentRequest?.[key]
      } catch {}
      return undefined
    }

    let validationSummary: any = null
    try {
      const vr = paymentRequest?.validate?.()
      validationSummary =
        vr && typeof vr === "object"
          ? {
              isValid: (vr as any).isValid,
              errorCount: Array.isArray((vr as any).errors) ? (vr as any).errors.length : undefined,
              errors: (vr as any).errors ?? undefined,
            }
          : vr
    } catch (e: any) {
      validationSummary = { threw: true, message: String(e?.message || e) }
    }

    return {
      cardNumber: safeGet("cardNumber"),
      expiryDate: safeGet("expiryDate"),
      cvv: safeGet("cvv"),
      cardholderName: safeGet("cardholderName"),
      securityCode: safeGet("securityCode"),
      expiryMonth: safeGet("expiryMonth"),
      expiryYear: safeGet("expiryYear"),
      keys: (() => {
        try { return Object.keys(paymentRequest || {}) } catch { return [] }
      })(),
      validation: validationSummary,
    }
  }

  const getProductField = (product: any, fieldId: string) => {
    try {
      if (typeof product?.getField === "function") {
        return product.getField(fieldId)
      }
    } catch {}

    if (product?.paymentProductFieldById?.[fieldId]) {
      return product.paymentProductFieldById[fieldId]
    }

    if (Array.isArray(product?.paymentProductFields)) {
      return product.paymentProductFields.find((f: any) => f?.id === fieldId) || null
    }

    return null
  }

  const buildPaymentRequest = (nextData: typeof formData) => {
    if (!paymentProduct) return null

    const paymentRequest = paymentProduct?.createPaymentRequest?.() || sdk?.createPaymentRequest?.(paymentProduct?.id)

    const maybeSet = (fieldId: string, value: any) => {
      const normalizedValue = String(value ?? "")
      if (!normalizedValue) return
      try {
        const field = getProductField(paymentProduct, fieldId)
        if (!field) return
        paymentRequest?.setValue?.(fieldId, normalizedValue)
      } catch {}
    }

    const cardholderName = String(nextData.cardholderName ?? "").trim()
    const cardNumber = normalizeCardNumber(nextData.cardNumber)
    const expiryMasked = normalizeExpiry(nextData.expiryDate)
    const expiryDigits = getExpiryDigits(nextData.expiryDate)
    const cvv = normalizeCvv(nextData.cvv)

    maybeSet("cardholderName", cardholderName)
    maybeSet("cardNumber", cardNumber)
    maybeSet("expiryDate", expiryDigits) // FIX: Worldline requires MMYY
    maybeSet("cvv", cvv)

    return paymentRequest
  }

  const extractFieldErrorMessage = (validationErrors: any, fallback: string) => {
    if (!Array.isArray(validationErrors) || validationErrors.length === 0) return ""
    const first =
      validationErrors?.[0]?.errorMessage ||
      validationErrors?.[0]?.message ||
      validationErrors?.[0]?.id
    return typeof first === "string" && first.trim() ? first : fallback
  }

  const validateWorldlineFields = (nextData: typeof formData) => {
    if (!paymentProduct) return

    const cardNumberValue = normalizeCardNumber(nextData.cardNumber)
    const expiryMasked = normalizeExpiry(nextData.expiryDate)
    const expiryDigits = getExpiryDigits(nextData.expiryDate)
    const cvvValue = normalizeCvv(nextData.cvv)

    const cardNumberField = getProductField(paymentProduct, "cardNumber")
    const expiryDateField = getProductField(paymentProduct, "expiryDate")
    const cvvField = getProductField(paymentProduct, "cvv") || getProductField(paymentProduct, "securityCode")

    const cardNumberValidation = cardNumberField?.validate?.(cardNumberValue)
    const expiryValidation = expiryDateField?.validate?.(expiryDigits)
    const cvvValidation = cvvField?.validate?.(cvvValue)

    setFieldErrors({
      cardNumber: extractFieldErrorMessage(cardNumberValidation, "Invalid card number"),
      expiryDate: extractFieldErrorMessage(expiryValidation, "Invalid expiry date"),
      cvv: extractFieldErrorMessage(cvvValidation, "Invalid CVV"),
    })
  }

  const applyFieldMask = (fieldId: "cardNumber" | "expiryDate" | "cvv", value: any) => {
    const raw = String(value ?? "")
    const field = getProductField(paymentProduct, fieldId)

    try {
      if (field && typeof field.applyMask === "function" && fieldId !== "expiryDate") {
        const masked: any = field.applyMask(raw)

        if (typeof masked === "string") return masked

        if (masked && typeof masked === "object") {
          if (typeof masked.formattedValue === "string") return masked.formattedValue
          if (typeof masked.value === "string") return masked.value
          if (typeof masked.maskedValue === "string") return masked.maskedValue
        }
      }
    } catch {}

    if (fieldId === "cardNumber") {
      const digits = raw.replace(/\D/g, "").slice(0, 16)
      return digits.replace(/(.{4})/g, "$1 ").trim()
    }

    if (fieldId === "expiryDate") {
      return raw.replace(/\D/g, "").slice(0, 4)
    }

    if (fieldId === "cvv") {
      return raw.replace(/\D/g, "").slice(0, 4)
    }

    return raw
  }

  const updateField = (name: keyof typeof formData, value: any) => {
    let nextValue = String(value ?? "")

    if (name === "cardNumber") {
      const digits = nextValue.replace(/\D/g, "").slice(0, 19)
      nextValue = digits.replace(/(.{4})/g, "$1 ").trim()
    } else if (name === "expiryDate") {
      const digits = nextValue.replace(/\D/g, "").slice(0, 4)
      nextValue = digits.length > 2 ? digits.slice(0, 2) + "/" + digits.slice(2) : digits
    } else if (name === "cvv") {
      nextValue = nextValue.replace(/\D/g, "").slice(0, 4)
    }

    setFormData((prev) => {
      const next = { ...prev, [name]: nextValue }
      validateWorldlineFields(next)
      return next
    })
  }

  useEffect(() => {
    onPaymentErrorRef.current = onPaymentError
  }, [onPaymentError])

  useEffect(() => {
    let active = true
    const initKey = `${countryCode}:${currencyCode}:${amountMinor}`
    ;(async () => {
      try {
        if (typeof window === "undefined") return
        if (initKeyRef.current === initKey) {
          return
        }

        initKeyRef.current = initKey
        setIsLoadingSession(true)
        setError(null)

        const cachedInit = worldlineInlineInitResultByKey.get(initKey)
        if (cachedInit) {
          if (!active) return
          setSdk(cachedInit.sdk)
          setPaymentProduct(cachedInit.paymentProduct)
          return
        }

        const inFlightInit = worldlineInlineInitPromiseByKey.get(initKey)
        const initPromise = inFlightInit ?? (async () => {
          const res = await fetch("/api/v1/payments/worldline/inline/session", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              amount: Number(paymentData?.amount || 0),
              currency: currencyCode,
            }),
          })
          const json = await res.json().catch(() => ({}))
          if (!res.ok || !json?.success || !json?.session) {
            throw new Error(json?.error || "Failed to initialize Worldline inline session")
          }
          const sessionData = json.session
          ;(window as any).__pmdWorldlineSessionData = sessionData
          let worldlineSession: any = null
          try {
            worldlineSession = new (Session as any)({
              clientSessionId: sessionData.clientSessionId,
              customerId: sessionData.customerId,
              clientApiUrl: sessionData.clientApiUrl,
              assetUrl: sessionData.assetUrl,
              appIdentifier: "PayMyDine-Checkout",
            })
          } catch {
            worldlineSession = new (Session as any)(
              sessionData.clientSessionId,
              sessionData.customerId,
              sessionData.clientApiUrl,
              sessionData.assetUrl,
              {
                environment: sessionData.environment || "TEST",
                appIdentifier: "PayMyDine-Checkout",
              }
            )
          }
          console.info("[WorldlineInlineCardForm] Session initialized")

          try {
            ;(window as any).__pmdWorldlineSdkDebug = {
              constructorName: worldlineSession?.constructor?.name ?? null,
              ownKeys: Object.keys(worldlineSession || {}),
              hasGetPaymentRequest: typeof worldlineSession?.getPaymentRequest === "function",
              hasGetEncryptor: typeof worldlineSession?.getEncryptor === "function",
              hasEncryptPaymentRequest: typeof worldlineSession?.encryptPaymentRequest === "function",
              hasPreparePaymentRequest: typeof worldlineSession?.preparePaymentRequest === "function",
              hasGetPaymentProduct: typeof worldlineSession?.getPaymentProduct === "function",
              protoKeys: Object.getOwnPropertyNames(Object.getPrototypeOf(worldlineSession || {})),
            }
          } catch {}

          const paymentContext = {
            countryCode,
            amountOfMoney: {
              amount: amountMinor,
              currencyCode,
            },
            isRecurring: false,
          }

          let product: any = null
          try {
            product = await worldlineSession.getPaymentProduct({
              productId: 1,
              paymentContext,
            })
          } catch {
            product = await worldlineSession.getPaymentProduct(1, paymentContext)
          }

          try {
            ;(window as any).__pmdWorldlineProductDebug = {
              id: product?.id ?? null,
              constructorName: product?.constructor?.name ?? null,
              ownKeys: Object.keys(product || {}),
              hasCreatePaymentRequest: typeof product?.createPaymentRequest === "function",
              hasGetField: typeof product?.getField === "function",
              fieldIds: Array.isArray(product?.paymentProductFields)
                ? product.paymentProductFields.map((f: any) => f?.id)
                : [],
            }
          } catch {}

          return { sdk: worldlineSession, paymentProduct: product }
        })()

        if (!inFlightInit) {
          worldlineInlineInitPromiseByKey.set(initKey, initPromise)
        }

        const resolvedInit = await initPromise
        worldlineInlineInitResultByKey.set(initKey, resolvedInit)
        worldlineInlineInitPromiseByKey.delete(initKey)
        if (!active) return
        setSdk(resolvedInit.sdk)
        setPaymentProduct(resolvedInit.paymentProduct)

        try {
          const pp: any = resolvedInit.paymentProduct
          const fields =
            Array.isArray(pp?.paymentProductFields)
              ? pp.paymentProductFields.map((f: any) => ({
                  id: f?.id,
                  type: f?.type,
                  dataType: f?.dataType,
                  preferredInputType: f?.displayHints?.preferredInputType,
                  obfuscate: f?.displayHints?.obfuscate,
                }))
              : []
          console.info("[WorldlineInlineCardForm] PRODUCT DEBUG", {
            productId: pp?.id,
            fields,
            hasCreatePaymentRequest: typeof pp?.createPaymentRequest === "function",
            hasGetField: typeof pp?.getField === "function",
          })
        } catch (e) {
          console.warn("[WorldlineInlineCardForm] PRODUCT DEBUG failed", e)
        }

        validateWorldlineFields(formData)
      } catch (err: any) {
        worldlineInlineInitPromiseByKey.delete(initKey)
        worldlineInlineInitResultByKey.delete(initKey)
        if (!initFailureShownRef.current) {
          console.error("[WorldlineInlineCardForm][session-init]", err)
          initFailureShownRef.current = true
        }
        if (!active) return
        const msg = "Could not initialize secure card payment."
        setError(msg)
        onPaymentErrorRef.current(msg)
      } finally {
        if (active) setIsLoadingSession(false)
      }
    })()
    return () => {
      active = false
    }
  }, [amountMinor, countryCode, currencyCode])

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!sdk || !paymentProduct) {
      const msg = "Worldline SDK not ready"
      setError(msg)
      onPaymentErrorRef.current(msg)
      return
    }

    let constructorAttempts: any[] = []
    let chosenStrategy: string | null = null
    let chosenRequest: any = null
    let chosenEncrypted: any = null
    let requestValuesAfterSet: any = null

    try {
      setIsProcessing(true)
      setError(null)

      const rawCardNumber = normalizeCardNumber(formData.cardNumber)
      const expiryInput = String(formData.expiryDate ?? "")
      const expiryDigits = getExpiryDigits(expiryInput)
      const rawCvv = normalizeCvv(formData.cvv)
      const rawCardholder = String(formData.cardholderName ?? "").trim()

      if (rawCardNumber.length < 12) throw new Error("Card number is incomplete")
      if (expiryDigits.length !== 4) throw new Error("Expiry date must be MM/YY")
      if (rawCvv.length < 3) throw new Error("CVV is incomplete")
      if (!rawCardholder) throw new Error("Cardholder name is required")

      const buildCandidates = () => {
        const out: Array<{ name: string; build: () => any }> = []

        out.push({
          name: "new PaymentRequest()+setPaymentProduct(paymentProduct)",
          build: () => {
            const req = new PaymentRequest()

            try {
              if (typeof req?.setPaymentProduct === "function") {
                req.setPaymentProduct(paymentProduct)
              }
            } catch {}

            return req
          }
        })

        return out
      }

      const safeSet = (paymentRequest: any, fieldId: string, value: string) => {
        const result: any = { fieldId, value, ok: false, errors: [] }

        if (!value) return result

        try {
          if (typeof paymentRequest?.setValue === "function") {
            paymentRequest.setValue(fieldId, value)
            result.ok = true
          } else {
            result.errors.push("setValue is unavailable")
          }
        } catch (e: any) {
          result.errors.push(String(e?.message || e))
        }

        return result
      }

      const safeGet = (paymentRequest: any, fieldId: string) => {
        try {
          if (typeof paymentRequest?.getValue === "function") {
            return paymentRequest.getValue(fieldId)
          }
        } catch {}

        try {
          return paymentRequest?.[fieldId]
        } catch {}

        return undefined
      }

      const encryptWithSdk = async (paymentRequest: any) => {
        if (typeof sdk?.encryptPaymentRequest === "function") {
          return await sdk.encryptPaymentRequest(paymentRequest)
        }

        if (typeof sdk?.preparePaymentRequest === "function") {
          return await sdk.preparePaymentRequest(paymentRequest)
        }

        if (typeof sdk?.getEncryptor === "function") {
          const encryptor = sdk.getEncryptor()
          if (typeof encryptor?.encrypt === "function") {
            return await encryptor.encrypt(paymentRequest)
          }
        }

        throw new Error("No supported Worldline encryption method found")
      }

      const candidates = buildCandidates().filter((x) => typeof x?.build === "function")

      for (const candidate of candidates) {
        const attempt: any = {
          strategy: candidate.name,
          buildOk: false,
          setResults: null,
          requestValuesAfterSet: null,
          encryptOk: false,
          encryptError: null,
        }

        try {
          const paymentRequest = candidate.build()
          if (!paymentRequest) {
            attempt.encryptError = "builder returned null"
            constructorAttempts.push(attempt)
            continue
          }

          attempt.buildOk = true

          const setResults = {
            cardNumber: safeSet(paymentRequest, "cardNumber", rawCardNumber),
            expiryDate: safeSet(paymentRequest, "expiryDate", expiryDigits),
            cvv: safeSet(paymentRequest, "cvv", rawCvv),
            cardholderName: safeSet(paymentRequest, "cardholderName", rawCardholder),
          }

          attempt.setResults = setResults
          attempt.requestValuesAfterSet = {
            cardNumber: safeGet(paymentRequest, "cardNumber"),
            expiryDate: safeGet(paymentRequest, "expiryDate"),
            cvv: safeGet(paymentRequest, "cvv"),
            cardholderName: safeGet(paymentRequest, "cardholderName"),
          }

          const encrypted = await encryptWithSdk(paymentRequest)

          attempt.encryptOk = true
          chosenStrategy = candidate.name
          chosenRequest = paymentRequest
          chosenEncrypted = encrypted
          requestValuesAfterSet = attempt.requestValuesAfterSet

          constructorAttempts.push(attempt)
          break
        } catch (e: any) {
          attempt.encryptError = String(e?.message || e)
          try {
            attempt.encryptErrorValidationErrors = e?.validationErrors ?? null
          } catch {}
          try {
            attempt.validationProbeAfterError = getPaymentRequestProbe(paymentRequest)
          } catch {}
          constructorAttempts.push(attempt)
        }
      }

      console.info("[WorldlineInlineCardForm] CONSTRUCTOR ATTEMPTS", constructorAttempts)

      try {
        const validateResult =
          typeof chosenRequest?.validate === "function"
            ? chosenRequest.validate()
            : null

        console.info("[WorldlineInlineCardForm] FINAL REQUEST VALIDATION", {
          chosenStrategy,
          requestValuesAfterSet,
          validateResult,
          probe: getPaymentRequestProbe(chosenRequest),
        })
      } catch (e) {
        console.warn("[WorldlineInlineCardForm] FINAL REQUEST VALIDATION failed", e)
      }

      if (!chosenRequest || !chosenEncrypted) {
        throw new Error("All PaymentRequest construction strategies failed")
      }

      const parsedPreparedOrEncrypted =
        typeof chosenEncrypted === "string"
          ? (() => {
              try {
                return JSON.parse(chosenEncrypted)
              } catch {
                return { encryptedCustomerInput: chosenEncrypted }
              }
            })()
          : chosenEncrypted

      const encryptedCustomerInput =
        parsedPreparedOrEncrypted?.encryptedCustomerInput ??
        parsedPreparedOrEncrypted?.encryptedFields ??
        parsedPreparedOrEncrypted?.payload?.encryptedCustomerInput ??
        parsedPreparedOrEncrypted?.paymentRequest?.encryptedCustomerInput ??
        chosenRequest?.encryptedCustomerInput ??
        ""

      const encodedClientMetaInfo =
        parsedPreparedOrEncrypted?.encodedClientMetaInfo ??
        parsedPreparedOrEncrypted?.payload?.encodedClientMetaInfo ??
        parsedPreparedOrEncrypted?.paymentRequest?.encodedClientMetaInfo ??
        chosenRequest?.encodedClientMetaInfo ??
        ""

      if (!encryptedCustomerInput || typeof encryptedCustomerInput !== "string") {
        throw new Error("Worldline encryption failed: encrypted customer payload is missing")
      }

      console.info('PMD FRONT CREATE PAYMENT PAYLOAD', {
  url: "/api/v1/payments/worldline/inline/create-payment",
  payloadPreview: (typeof payload !== 'undefined' ? payload : (typeof requestBody !== 'undefined' ? requestBody : (typeof body !== 'undefined' ? body : null))),
  encryptedRequestPreview: (typeof encryptedRequest !== 'undefined' ? encryptedRequest : null)
});
const payRes = await fetch("/api/v1/payments/worldline/inline/create-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: Number(paymentData?.amount || 0),
          currency: String(currency || "EUR").toUpperCase(),
          paymentProductId: Number(paymentProduct?.id || 1),
          encryptedCustomerInput,
          encodedClientMetaInfo,
          cardholderName: formData.cardholderName,
          email: formData.email,
          phone: formData.phone,
        }),
      })

      const payJson = await payRes.json().catch(() => ({}))

      if (!payRes.ok || !payJson?.success || !payJson?.payment_id) {
        throw new Error(payJson?.error || "Worldline inline payment failed")
      }

      const verifyRes = await fetch("/api/v1/payments/worldline/inline/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payment_id: String(payJson.payment_id) }),
      })

      const verifyJson = await verifyRes.json().catch(() => ({}))

      if (!verifyRes.ok || !verifyJson?.success || !verifyJson?.is_paid) {
        throw new Error("Worldline payment is not finalized yet")
      }

      onPaymentComplete({
        success: true,
        transactionId: String(verifyJson.payment_id || payJson.payment_id),
        paymentMethod: "worldline",
      } as any)
    } catch (e: any) {
      const rawMsg = typeof e?.message === "string" ? e.message : ""

      const expiryInput = String(formData.expiryDate ?? "")
      const expiryDigits = getExpiryDigits(expiryInput)
      const expiryMasked = expiryDigits.length >= 4 ? `${expiryDigits.slice(0, 2)}/${expiryDigits.slice(2, 4)}` : expiryInput

      const availableFieldIds = Array.isArray(paymentProduct?.paymentProductFields)
        ? paymentProduct.paymentProductFields.map((f: any) => String(f?.id ?? "")).filter(Boolean)
        : (
            typeof paymentProduct?.getFields === "function"
              ? paymentProduct.getFields().map((f: any) => String(f?.id ?? "")).filter(Boolean)
              : Object.keys(paymentProduct?.paymentProductFieldById || {})
          )

      const debugPayload = {
        rawError: rawMsg,
        paymentProductId: Number(paymentProduct?.id || 0),
        sdkDebug: (() => {
          try {
            return (window as any).__pmdWorldlineSdkDebug ?? null
          } catch (e: any) {
            return { threw: true, message: String(e?.message || e) }
          }
        })(),
        sessionDataDebug: (() => {
          try {
            const s = (window as any).__pmdWorldlineSessionData
            if (!s) return null
            return {
              keys: Object.keys(s || {}),
              clientSessionIdPresent: Boolean(s?.clientSessionId),
              customerIdPresent: Boolean(s?.customerId),
              clientApiUrl: s?.clientApiUrl ?? null,
              assetUrl: s?.assetUrl ?? null,
              environment: s?.environment ?? null,
            }
          } catch (e: any) {
            return { threw: true, message: String(e?.message || e) }
          }
        })(),
        paymentProductDebug: (() => {
          try {
            return (window as any).__pmdWorldlineProductDebug ?? null
          } catch (e: any) {
            return { threw: true, message: String(e?.message || e) }
          }
        })(),        availableFieldIds,
        sentValues: {
          cardNumber: String(formData.cardNumber ?? ""),
          expiryDate: expiryInput,
          expiryDigits,
          expiryMasked,
          cvv: String(formData.cvv ?? ""),
          cardholderName: String(formData.cardholderName ?? ""),
          email: String(formData.email ?? ""),
        },
        chosenStrategy,
        requestValuesAfterSet,
        constructorAttempts,
      }

      const msg =
        (rawMsg || "Payment could not be completed. Please check your details and try again.") +
        "\n\nDEBUG:\n" +
        JSON.stringify(debugPayload, null, 2)

      setError(msg)
      onPaymentErrorRef.current(msg)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className={cn("space-y-4", className)}>
      <div className="space-y-2">
        <Label htmlFor="wlCardNumber">Card number</Label>
        <Input
          id="wlCardNumber"
          value={formData.cardNumber}
          onChange={(e) => updateField("cardNumber", e.target.value)}
          required
          autoComplete="cc-number"
          className="h-11 rounded-xl text-[15px]"
        />
        {fieldErrors.cardNumber ? <p className="text-xs text-red-500">{fieldErrors.cardNumber}</p> : null}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="wlExpiry">Expiry (MMYY)</Label>
          <Input
            id="wlExpiry"
            value={formData.expiryDate}
            onChange={(e) => updateField("expiryDate", e.target.value)}
            required
            autoComplete="off"
            className="h-11 rounded-xl"
          />
          {fieldErrors.expiryDate ? <p className="text-xs text-red-500">{fieldErrors.expiryDate}</p> : null}
        </div>
        <div className="space-y-2">
          <Label htmlFor="wlCvv">CVV</Label>
          <Input
            id="wlCvv"
            value={formData.cvv}
            onChange={(e) => updateField("cvv", e.target.value)}
            required
            autoComplete="cc-csc"
            className="h-11 rounded-xl"
          />
          {fieldErrors.cvv ? <p className="text-xs text-red-500">{fieldErrors.cvv}</p> : null}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="wlCardholder">Cardholder name</Label>
          <Input
            id="wlCardholder"
            value={formData.cardholderName}
            onChange={(e) => updateField("cardholderName", e.target.value)}
            required
            className="h-11 rounded-xl"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="wlEmail">Email</Label>
          <Input
            id="wlEmail"
            type="email"
            value={formData.email}
            onChange={(e) => updateField("email", e.target.value)}
            required
            className="h-11 rounded-xl"
          />
        </div>
      </div>
      {error && (
        <pre className="text-xs text-red-500 whitespace-pre-wrap break-all rounded-xl p-3 bg-red-50 border border-red-200 overflow-auto">
{error}
        </pre>
      )}
      <button
        type="submit"
        disabled={isLoadingSession || isProcessing || !sdk || !paymentProduct || !formIsValid}
        className="relative w-full min-w-full max-w-full h-[54px] rounded-2xl border-0 overflow-hidden disabled:opacity-60 disabled:cursor-not-allowed"
        style={{
          background: "transparent",
          boxShadow: "none",
        }}
      >
        <span
          aria-hidden="true"
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 0,
            borderRadius: "9999px",
            background: "linear-gradient(135deg, #063F2F 0%, #062F2A 100%)",
            boxShadow: "0 8px 22px rgba(6, 47, 42, 0.24)",
            pointerEvents: "none",
          }}
        />
        <span
          style={{
            position: "relative",
            zIndex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            color: "#FFFFFF",
            fontSize: "16px",
            fontWeight: 700,
            width: "100%",
          }}
        >
          {isProcessing ? (
            <>
              <span
                className="animate-spin"
                style={{
                  width: "16px",
                  height: "16px",
                  border: "2px solid rgba(255,255,255,0.35)",
                  borderTopColor: "#FFFFFF",
                  borderRadius: "9999px",
                }}
              />
              <span>Processing...</span>
            </>
          ) : isLoadingSession ? (
            <span>Initializing...</span>
          ) : (
            <>
              <Lock className="h-4 w-4" />
              <span>Pay</span>
            </>
          )}
        </span>
      </button>
    </form>
  )
}

// PayPal Form Component
export function PayPalForm({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className,
  paypalFundingSource = "paypal",
}: SecurePaymentFormProps) {
  const [{ isPending }] = usePayPalScriptReducer()
  const [isProcessing, setIsProcessing] = useState(false)

  const createOrder = async () => {
    try {
      const response = await fetch('/api/v1/payments/paypal/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paymentData),
      })

      const json = await response.json().catch(() => ({}))
      console.log('[PMD][PayPalForm][createOrder] =>', json)

      const paypalOrderId = json?.orderID || json?.orderId || json?.id || json?.paypal?.id

      if (!response.ok || !json?.success || !paypalOrderId) {
        throw new Error(json?.error || 'Failed to create PayPal order')
      }

      return paypalOrderId
    } catch (error: any) {
      onPaymentError(error?.message || 'Failed to create PayPal order')
      throw error
    }
  }

  const onApprove = async (data: any) => {
    setIsProcessing(true)

    try {
      const response = await fetch('/api/v1/payments/paypal/capture-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderID: data?.orderID || data?.orderId,
          orderId: data?.orderID || data?.orderId,
          paymentData,
        }),
      })

      const result = await response.json().catch(() => ({}))
      console.log('[PMD][PayPalForm][onApprove] =>', result)

      if (response.ok && result?.success) {
        onPaymentComplete({
          success: true,
          transactionId: result.transactionId || result.captureID || result.orderID || data?.orderID,
          paymentMethod: 'paypal',
        })
      } else {
        onPaymentError(result?.error || 'Payment failed')
      }
    } catch (error: any) {
      onPaymentError(error?.message || 'Payment failed')
    } finally {
      setIsProcessing(false)
    }
  }

  const onError = (error: any) => {
    onPaymentError(error?.message || 'PayPal payment failed')
  }

  if (isPending) {
    return (
      <div className={cn("flex items-center justify-center p-8", className)}>
        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        <span className="ml-2">Loading PayPal...</span>
      </div>
    )
  }

  return (
    <div className={cn("space-y-4 bg-transparent w-full", className)}>
      <div className="text-center">
        <p className="text-sm text-gray-600 mb-4">

        </p>
      </div>

      <div className="paypal-clean-wrap">
        <PayPalButtons
        fundingSource={paypalFundingSource}
        createOrder={createOrder}
        onApprove={onApprove}
        onError={onError}
        disabled={isProcessing}

        style={{
          layout: 'vertical',
          color: 'blue',
          shape: 'pill',
          label: 'paypal',
          tagline: false,
          height: 45,
          borderRadius: 14,
        }}


      />
      </div>
      <style jsx>{`
        .paypal-clean-wrap {
          background: transparent !important;
          border-radius: 12px;
          overflow: hidden;
          padding: 0;
          margin: 0;
          line-height: 0;
        }

        .paypal-clean-wrap :global(div),
        .paypal-clean-wrap :global(.paypal-buttons),
        .paypal-clean-wrap :global(.paypal-button-container),
        .paypal-clean-wrap :global(.paypal-button-row),
        .paypal-clean-wrap :global(iframe) {
          background: transparent !important;
        }

        .paypal-clean-wrap :global(.paypal-button-container) {
          border-radius: 12px !important;
          overflow: hidden !important;
          min-width: 100% !important;
          max-width: 100% !important;
        }

        .paypal-clean-wrap :global(.paypal-button-row) {
          border-radius: 12px !important;
          overflow: hidden !important;
        }

        .paypal-clean-wrap :global(iframe) {
          border-radius: 12px !important;
          display: block !important;
        }
      `}</style>
    </div>
  )
}

// Apple Pay Button Component
export function ApplePayButton({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className
}: SecurePaymentFormProps) {
  const [isAvailable, setIsAvailable] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    // Check if Apple Pay is available
    if (typeof window !== 'undefined' && window.ApplePaySession) {
      setIsAvailable(ApplePaySession.canMakePayments())
    }
  }, [])

  const handleApplePay = async () => {
    if (!isAvailable) {
      onPaymentError('Apple Pay is not available on this device')
      return
    }

    setIsProcessing(true)

    try {
      const paymentRequest = {
        countryCode: 'US',
        currencyCode: paymentData.currency,
        supportedNetworks: ['visa', 'masterCard', 'amex'],
        merchantCapabilities: ['supports3DS'],
        total: {
          label: 'PayMyDine',
          amount: paymentData.amount.toFixed(2),
        },
      }

      const session = new ApplePaySession(3, paymentRequest)

      session.onvalidatemerchant = async (event) => {
        try {
          const response = await fetch('/api/payments/validate-apple-pay', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ validationURL: event.validationURL }),
          })

          const { merchantSession } = await response.json()
          session.completeMerchantValidation(merchantSession)
        } catch (error) {
          session.abort()
          onPaymentError('Failed to validate merchant')
        }
      }

      session.onpaymentauthorized = async (event) => {
        try {
          const response = await fetch('/api/payments/process-apple-pay', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...paymentData,
              paymentData: event.payment,
            }),
          })

          const result = await response.json()

          if (result.success) {
            session.completePayment(ApplePaySession.STATUS_SUCCESS)
            onPaymentComplete({
              success: true,
              transactionId: result.transactionId,
              paymentMethod: 'applepay',
            })
          } else {
            session.completePayment(ApplePaySession.STATUS_FAILURE)
            onPaymentError(result.error || 'Payment failed')
          }
        } catch (error) {
          session.completePayment(ApplePaySession.STATUS_FAILURE)
          onPaymentError('Payment processing failed')
        }
      }

      session.begin()
    } catch (error: any) {
      onPaymentError(error.message)
    } finally {
      setIsProcessing(false)
    }
  }

  if (!isAvailable) {
    return null
  }

  return (
    <div className={cn("space-y-4 bg-transparent w-full", className)}>
      <Button
        onClick={handleApplePay}
        disabled={isProcessing}
        className="w-full bg-black text-white hover:bg-gray-800"
      >
        {isProcessing ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Processing...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-5 h-5">🍎</div>
            Pay with Apple Pay
          </div>
        )}
      </Button>
    </div>
  )
}

// Google Pay Button Component
export function GooglePayButton({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className
}: SecurePaymentFormProps) {
  const [isAvailable, setIsAvailable] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    // Check if Google Pay is available
    if (typeof window !== 'undefined' && window.google) {
      const paymentsClient = new window.google.payments.api.PaymentsClient({
        environment: process.env.NODE_ENV === 'production' ? 'PRODUCTION' : 'TEST',
      })

      paymentsClient.isReadyToPay({
        allowedPaymentMethods: [{
          type: 'CARD',
          parameters: {
            allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: ['VISA', 'MASTERCARD', 'AMEX'],
          },
        }],
      }).then((result: any) => {
        setIsAvailable(result.result)
      }).catch(() => {
        setIsAvailable(false)
      })
    }
  }, [])

  const handleGooglePay = async () => {
    if (!isAvailable) {
      onPaymentError('Google Pay is not available on this device')
      return
    }

    setIsProcessing(true)

    try {
      const paymentsClient = new window.google.payments.api.PaymentsClient({
        environment: process.env.NODE_ENV === 'production' ? 'PRODUCTION' : 'TEST',
      })

      const paymentDataRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
        allowedPaymentMethods: [{
          type: 'CARD',
          parameters: {
            allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: ['VISA', 'MASTERCARD', 'AMEX'],
          },
          tokenizationSpecification: {
            type: 'PAYMENT_GATEWAY',
            parameters: {
              gateway: 'stripe',
              gatewayMerchantId: process.env.NEXT_PUBLIC_STRIPE_ACCOUNT_ID,
            },
          },
        }],
        transactionInfo: {
          totalPriceStatus: 'FINAL',
          totalPrice: paymentData.amount.toFixed(2),
          currencyCode: paymentData.currency,
        },
        merchantInfo: {
          merchantId: paymentData.restaurantId,
          merchantName: 'PayMyDine',
        },
      }

      const paymentDataResponse = await paymentsClient.loadPaymentData(paymentDataRequest)

      const response = await fetch('/api/payments/process-google-pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...paymentData,
          paymentData: paymentDataResponse,
        }),
      })

      const result = await response.json()

      if (result.success) {
        onPaymentComplete({
          success: true,
          transactionId: result.transactionId,
          paymentMethod: 'googlepay',
        })
      } else {
        onPaymentError(result.error || 'Payment failed')
      }
    } catch (error: any) {
      onPaymentError(error.message)
    } finally {
      setIsProcessing(false)
    }
  }

  if (!isAvailable) {
    return null
  }

  return (
    <div className={cn("space-y-4 bg-transparent w-full", className)}>
      <Button
        onClick={handleGooglePay}
        disabled={isProcessing}
        className="w-full bg-blue-600 text-white hover:bg-blue-700"
      >
        {isProcessing ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Processing...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-5 h-5">G</div>
            Pay with Google Pay
          </div>
        )}
      </Button>
    </div>
  )
}

// Cash Payment Component
export function CashPaymentForm({
  paymentData,
  onPaymentComplete,
  onPaymentError,
  className
}: SecurePaymentFormProps) {
  const [isProcessing, setIsProcessing] = useState(false)

  const handleCashPayment = async () => {
    setIsProcessing(true)

    try {
      const response = await fetch('/api/payments/process-cash', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paymentData),
      })

      const result = await response.json()

      if (result.success) {
        onPaymentComplete({
          success: true,
          transactionId: result.transactionId,
          paymentMethod: 'cash',
        })
      } else {
        onPaymentError(result.error || 'Payment recording failed')
      }
    } catch (error: any) {
      onPaymentError(error.message)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className={cn("space-y-4 bg-transparent w-full", className)}>
      <div className="text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CreditCard className="w-8 h-8 text-green-600" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Cash Payment</h3>
        <p className="text-sm text-gray-600 mb-4">
          A waiter will come to collect payment at your table.
        </p>
        <div className="text-2xl font-bold text-green-600">
          ${paymentData.amount.toFixed(2)}
        </div>
      </div>

      <Button
        onClick={handleCashPayment}
        disabled={isProcessing}
        className="w-full bg-green-600 text-white hover:bg-green-700"
      >
        {isProcessing ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Recording...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Confirm Cash Payment
          </div>
        )}
      </Button>
    </div>
  )
}